<footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy; 2018 - Library Management System | Brought To You By <a href="https://code-projects.org/">Code-Projects</a></strong>
</footer>