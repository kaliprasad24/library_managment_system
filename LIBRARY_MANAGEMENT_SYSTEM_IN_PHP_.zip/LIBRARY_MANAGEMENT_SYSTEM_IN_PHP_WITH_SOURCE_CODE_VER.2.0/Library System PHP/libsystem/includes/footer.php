<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Open Admin Panel and Add/View user to know Login ID</b>
      </div>
      <strong>&copy; 2018 - Library Management System | Brought To You By <a href="https://code-projects.org/">Code-Projects</a></strong>
      </div>
    <!-- /.container -->
</footer>